// JavaScript Document
 
/*
Custom.js file includes following
 
- DONUT CHART
- CAROUSEL SLIDER
- TO TOP
- PARALLAX
- FITVID
- PRELOADER
- COUNTER UP
- MAGNIFIC POPUP
- STICKY NAV 
*/

$(document).ready(function() {
    'use strict';
      /*********************************************************************************** DONUT CHART STARTS */
    $(".donut").donutchart("animate");
     /*********************************************************************************** DONUT CHART ENDS */
      /*********************************************************************************** CAROUSEL SLIDER STARTS */
    var owl = $('.testimonial-carousel');
    owl.owlCarousel({
        autoplay: false,
        autoplayHoverPause: true,
        nav: false,
        dots: true,
        mouseDrag: true,
        smartSpeed: 500,
        margin: 0,
        loop: true,
        singleItem: true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
    var owl = $('.testimonials-carousel');
    owl.owlCarousel({
        autoplay: false,
        autoplayHoverPause: true,
        nav: false,
        dots: true,
        mouseDrag: true,
        smartSpeed: 500,
        margin: 0,
        loop: true,
        singleItem: true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
    var owl = $('.the-benefits-carousel');
    owl.owlCarousel({
        autoplay: false,
        autoplayHoverPause: true,
        nav: false,
        dots: true,
        mouseDrag: true,
        smartSpeed: 500,
        margin: 0,
        loop: true,
        singleItem: true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
    var owl = $('.portfolio-carousel');
    owl.owlCarousel({
        autoplay: false,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        mouseDrag: true,
        smartSpeed: 500,
        margin: 0,
        loop: true,
        singleItem: true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
     /*********************************************************************************** CAROUSEL SLIDER ENDS */
      
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();
        } else {
            $('.scrollup').fadeOut();
        }
    });
    $('.scrollup').on("click", function() {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
      /*********************************************************************************** TO TOP ENDS */
          /*********************************************************************************** PARALLAX STARTS */
    $('.parallax-1, .parallax-2, .parallax-3, .parallax-4, .parallax-5').parallax("50%", 0.5);
    /*********************************************************************************** PARALLAX ENDS */
      /*********************************************************************************** ACCORDION STARTS */
    function toggleChevron(e) {
        $(e.target).prev('.panel-heading').find("i.indicator2").toggleClass('fa-plus fa-minus');
    }
    $('.accordion_plusminus').on('hidden.bs.collapse', toggleChevron);
    $('.accordion_plusminus').on('shown.bs.collapse', toggleChevron);
      /*********************************************************************************** ACCORDION ENDS */
     /*********************************************************************************** FITVID STARTS */
    $(".fitvid").fitVids();
       /*********************************************************************************** FITVID ENDS */
          /*********************************************************************************** PRELOADER STARTS */
    $('#status').fadeOut();
    $('#preloader').delay(350).fadeOut('slow');
       /***********************************************************************************  PRELOADER ENDS */
       /*********************************************************************************** COUNTER UP STARTS */
    $('.count').counterUp({
        delay: 10,
        time: 1000
    });
     /*********************************************************************************** COUNTER UP ENDS */
     /*********************************************************************************** MAGNIFIC POPUP STARTS*/
	 
	 

	// Responsive Menu Events
		var addActiveClass = false;
		$("#mainMenu li.dropdown > a, #mainMenu li.dropdown-submenu > a").on("click", function(e) {
			if($this.width() > 979)  { return ;  } 
			e.preventDefault();
			addActiveClass = $(this).parent().hasClass("resp-active");
			$("#mainMenu").find(".resp-active").removeClass("resp-active");
			if(!addActiveClass) {
				$(this).parents("li").addClass("resp-active");
			}

			return;

		});



 
    $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
    $('.image-popup-vertical-fit').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        mainClass: 'mfp-img-mobile',
        image: {
            verticalFit: true
        }
    });
	
	
	

		
	
	
    /*********************************************************************************** MAGNIFIC POPUP STARTS */
/*********************************************************************************** STICKY NAV STARTS */
    
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 1) {
            $(".navigation").removeClass("normal").addClass("sticky");
        } else {
            $(".navigation").removeClass("sticky").addClass("normal");
        }
    });
    /*********************************************************************************** STICKY NAV ENDS */
	  
});

function changeImage(a) {
             document.getElementById("img").src=a;
         }
         function changeImage1(a) {
             document.getElementById("img1").src=a;
         }
         function changeImage2(a) {
             document.getElementById("img2").src=a;
         }
         function changeImage3(a) {
             document.getElementById("img3").src=a;
         }
		 
		 

			// Contact Form Submition
	function checkRequire(formId , targetResp){
		targetResp.html('');
		var email = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
		var url = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/;
		var image = /\.(jpe?g|gif|png|PNG|JPE?G)$/;
		var mobile = /^[\s()+-]*([0-9][\s()+-]*){6,20}$/;
		var facebook = /^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]/;
		var twitter = /^(https?:\/\/)?(www\.)?twitter.com\/[a-zA-Z0-9(\.\?)?]/;
		var google_plus = /^(https?:\/\/)?(www\.)?plus.google.com\/[a-zA-Z0-9(\.\?)?]/;
		var check = 0;
		$('#er_msg').remove();
		var target = (typeof formId == 'object')? $(formId):$('#'+formId);
		target.find('input , textarea , select').each(function(){
			if($(this).hasClass('require')){
				if($(this).val().trim() == ''){
					check = 1;
					$(this).focus();
					targetResp.html('You missed out some fields.');
					$(this).addClass('error');
					return false;
				}else{
					$(this).removeClass('error');
				}
			}
			if($(this).val().trim() != ''){
				var valid = $(this).attr('data-valid');
				if(typeof valid != 'undefined'){
					if(!eval(valid).test($(this).val().trim())){
						$(this).addClass('error');
						$(this).focus();
						check = 1;
						targetResp.html($(this).attr('data-error'));
						return false;
					}else{
						$(this).removeClass('error');
					}
				}
			}
		});
		return check;
	}
	$(".submitForm").on("click", function() {
		var _this = $(this);
		var targetForm = _this.closest('form');
		var errroTarget = targetForm.find('.response');
		var check = checkRequire(targetForm , errroTarget);
		if(check == 0){
			var formDetail = new FormData(targetForm[0]);
			formDetail.append('form_type' , _this.attr('form-type'));
			$.ajax({
				method : 'post',
				url : 'ajax.php',
				data:formDetail,
				cache:false,
				contentType: false,
				processData: false
			}).done(function(resp){
				if(resp == 1){
					targetForm.find('input').val('');
					targetForm.find('textarea').val('');
					errroTarget.html('<p style="color:green;">Mail has been sent successfully.</p>');
				}else{
					errroTarget.html('<p style="color:red;">Something went wrong please try again latter.</p>');
				}
			});
		}
	});
	