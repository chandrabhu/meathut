</body>
<!-- Start Footer Section -->
<footer>
  <div class="container">

   <!-- Start Subscribe & Social Links Widget -->
   <div class="row footer-row">
    <div class="col-lg-4 col-md-4 col-sm-4 contact-widget">
     <div class="footer-widget mail-subscribe-widget">
      <div class="title">Call Now</div>
      <img src="<?php echo base_url('assets/images/blog/4.png'); ?>" alt="" class="liner">

      <a class="phone" href="tel:08709289369">08709289369</a>
      <div>
        <br>
        <h2 class="widgettitle">Get Special Email Offers</h2>
        <img src="<?php echo base_url('assets/images/blog/4.png'); ?>" alt="linear" class="liner">
      </div>

      <!--  Starting Of Subscriber Form -->
      <form class="mail-form" >
       <div class="input-group">
        <input type="email" name="email" placeholder="Your Email" class="form-control form-control-footer" required="Please Enter Email">
        <span class="input-group-btn">
         <button class="btn btn-primary btn_footer-form" type="submit">JOIN US</button>
       </span>
     </div>
   </form>
   <!--  Ending Of Subscriber Form -->

 </div>
</div>

<div class="col-lg-1"></div>

<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 links">
 <h2 class="widgettitle">Our service</h2>
 <img src="<?php echo base_url('assets/images/blog/4.png'); ?>" alt="" class="liner">
 <ul class="usefull-links">
  <li><a href="<?php echo base_url('meathut/about')?>">About Us</a></li>
  <li><a href="#">What We do</a></li>
  <li><a href="<?php echo base_url('meathut/works'); ?>">Our works</a></li>
  <li><a href="<?php echo base_url('meathut/faq'); ?>">FAQ'S</a></li>
</ul>
</div>
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 links">

 <h2 class="widgettitle">OUR STORY</h2>
 <img src="<?php echo base_url('assets/images/blog/4.png'); ?>" alt="linear" class="liner">

 <ul class="usefull-links">
  <li><a href="<?php echo base_url('meathut/contact'); ?>">Contact Us</a></li>
  <li><a href="#">We are Hiring </a></li>
  <li><a href="<?php echo base_url('meathut/news'); ?>">The News</a></li>
  <li><a href="<?php echo base_url('meathut/privacy_policy'); ?>">Privacy Policy</a></li>
  <li><a href="<?php echo base_url('meathut/terms_and_conditions'); ?>">Terms &amp; Conditions</a></li>
  <li><a href="<?php echo base_url('meathut/sitemap'); ?>">Sitemap</a></li>
  <!-- <li><a href="">Our Mobile App</a></li> -->
  <li><a href="<?php echo base_url('meathut/store'); ?>">Find a store</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-3 col-sm-3 footer-pic">
 <h2 class="widgettitle">OUR STORY</h2>

 <img src="<?php echo base_url('assets/images/blog/4.png'); ?>" alt="" class="liner">
 <div class="row m-0">
  <div class="col-lg-4 col-md-4 col-sm-4  col-xs-3 padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s1.jpg'); ?>" alt="" class="img-responsive">
 </div>
 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3  padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s2.jpg'); ?>" alt="" class="img-responsive">
 </div>
 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3  padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s3.jpg'); ?>" alt="" class="img-responsive">
 </div>
</div>
<div class="row m-0">
  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3 padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s4.jpg'); ?>" alt="" class="img-responsive">
 </div>
 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3  padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s5.jpg'); ?>" alt="" class="img-responsive">
 </div>
 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3 padding-zero">
   <img src="<?php echo base_url('assets/images/blog/s6.jpg'); ?>" alt="" class="img-responsive">
 </div>
</div>
</div>
</div>
<!-- .row -->
</div>
</footer>
<!-- Start Copyright -->
<div class="copyright-section">
  <div class="container">
   <div class="row">
    <div class="col-md-6">
      <div>
        <h4>We are Social</h4>
      </div>
      <div class="footer-icons">
        <a href="#" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a>
        <a href="#" target="_blank" class="tweet"><i class="fa fa-twitter"></i></a>
        <a href="#" target="_blank" class="linked"><i class="fa fa-linkedin-square"></i></a>
        <a href="#" target="_blank" class="utube"><i class="fa fa-youtube"></i></a>
        <a href="#" target="_blank" class="app"><i class="fa fa-whatsapp"></i></a>
        <a href="#" target="_blank" class="interest"><i class="fa fa-pinterest"></i></a>
      </div>
    </div>
    <!-- .col-md-6 -->
    <div class="col-md-6 butcher-col">
     <p>Copyright <?php echo date("Y"); ?> © <a href="#" class="trademark">MeatHut </a>
      <a href="Meathut" class="design"></a>
    </p>
  </div>
  <!-- .col-md-6 -->
</div>
<!-- .row -->
</div>
</div>
<!-- End Copyright -->
      <!-- /. About our frim ends
       ========================================================================= -->
       <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
       <!-- Include all compiled plugins (below), or include individual files as needed -->
       <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
       <!-- Bootstrap Dropdown Hover JS -->
       <script src="<?php echo base_url('assets/js/dropdownhover/bootstrap-dropdownhover.min.js'); ?>"></script>
       <!-- REVOLUTION JS FILES -->
       <script src="<?php echo base_url('assets/revolution/js/jquery.themepunch.tools.min.js'); ?>" type="text/javascript"></script>
       <script src="<?php echo base_url('assets/revolution/js/jquery.themepunch.revolution.min.js'); ?>" type="text/javascript"></script>
      <!-- SLIDER REVOLUTION 5.0 EXTENSIONS
         (Load Extensions only on Local File Systems !
         The following part can be removed on Server for On Demand Loading) -->
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.actions.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.carousel.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.kenburn.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.migration.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.navigation.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.parallax.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.slideanims.min.js'); ?>" type="text/javascript"></script>
         <script src="<?php echo base_url('assets/revolution/js/extensions/revolution.extension.video.min.js'); ?>" type="text/javascript"></script>
         
         <script type="text/javascript">
          var tpj = jQuery;

          var revapi1078;
          tpj(document).ready(function () {
            if (tpj("#rev_slider_1078_1").revolution == undefined) {
              revslider_showDoubleJqueryError("#rev_slider_1078_1");
            } else {
              revapi1078 = tpj("#rev_slider_1078_1").show().revolution({
                sliderType: "standard",
                jsFileLocation: "revolution/js/",
                sliderLayout: "fullscreen",
                dottedOverlay: "none",
                delay: 9000,
                navigation: {
                  keyboardNavigation: "off",
                  keyboard_direction: "horizontal",
                  mouseScrollNavigation: "off",
                  mouseScrollReverse: "default",
                  onHoverStop: "off",
                  touch: {
                    touchenabled: "on",
                    swipe_threshold: 75,
                    swipe_min_touches: 1,
                    swipe_direction: "horizontal",
                    drag_block_vertical: false
                  },
                  arrows: {
                    style: "zeus",
                    enable: true,
                    hide_onmobile: true,
                    hide_under: 600,
                    hide_onleave: true,
                    hide_delay: 200,
                    hide_delay_mobile: 1200,
                    tmp: '<div class="tp-title-wrap">    <div class="tp-arr-imgholder"><\/div> <\/div>',
                    left: {
                      h_align: "left",
                      v_align: "center",
                      h_offset: 30,
                      v_offset: 0
                    },
                    right: {
                      h_align: "right",
                      v_align: "center",
                      h_offset: 30,
                      v_offset: 0
                    }
                  },
                  bullets: {
                   enable: true,
                   hide_onmobile: true,
                   hide_under: 600,
                   style: "metis",
                   hide_onleave: true,
                   hide_delay: 200,
                   hide_delay_mobile: 1200,
                   direction: "horizontal",
                   h_align: "center",
                   v_align: "bottom",
                   h_offset: 0,
                   v_offset: 30,
                   space: 5
                 }
               },
               viewPort: {
                enable: true,
                outof: "pause",
                visible_area: "80%",
                presize: false
              },
              responsiveLevels: [1240, 1024, 778, 480],
              visibilityLevels: [1240, 1024, 778, 480],
              gridwidth: [1240, 1024, 778, 480],
              gridheight: [600, 600, 500, 400],
              lazyType: "none",
              parallax: {
                type: "mouse",
                origo: "slidercenter",
                speed: 2000,
                levels: [2, 3, 4, 5, 6, 7, 12, 16, 10, 50, 46, 47, 48, 49, 50, 55],
                type: "mouse",
              },
              shadow: 0,
              spinner: "off",
              stopLoop: "off",
              stopAfterLoops: -1,
              stopAtSlide: -1,
              shuffle: "off",
              autoHeight: "off",
              hideThumbsOnMobile: "off",
              hideSliderAtLimit: 0,
              hideCaptionAtLimit: 0,
              hideAllCaptionAtLilmit: 0,
              debugMode: false,
              fallbacks: {
                simplifyAll: "off",
                nextSlideOnWindowFocus: "off",
                disableFocusListener: false,
              }
            });
            }
          });
          /*ready*/
        </script>
        <!-- Parallax -->
        <script src="<?php echo base_url('assets/js/parallax/jquery.parallax-1.1.3.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/js/parallax/jquery.localscroll-1.2.7-min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/js/parallax/jquery.scrollTo-1.4.2-min.js'); ?>" type="text/javascript"></script>
        <!-- Owl Carousel -->
        <script src="<?php echo base_url('assets/js/owl-carousel/owl.carousel.js'); ?>" type="text/javascript"></script>
        <!-- FitVids -->
        <script src="<?php echo base_url('assets/js/fitvids/jquery.fitvids.js'); ?>" type="text/javascript"></script>
        <!-- Isotope -->
        <script src="<?php echo base_url('assets/js/isotope/jquery.isotope.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/js/isotope/custom-isotope-mansory.js'); ?>" type="text/javascript"></script>
        <!-- Magnific Popup core JS file -->
        <script src="<?php echo base_url('assets/js/magnific-popup/jquery.magnific-popup.js'); ?>" type="text/javascript"></script>
        <!-- Counter Up -->
        <script src="<?php echo base_url('assets/js/counterup/waypoints.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/counterup/jquery.counterup.min.js'); ?>"></script>
        <!-- AJAX Contact Form -->
        <script src="<?php echo base_url('assets/js/contact/contact-form.js'); ?>" type="text/javascript"></script>
        <!-- Donut Chart -->
        <script src="<?php echo base_url('assets/js/progress-bars/jquery.donutchart.js'); ?>" type="text/javascript"></script>
        <!-- Custom JS -->
        <script src="<?php echo base_url('assets/js/custom/custom.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/pmenu/pmenu.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/modernizr.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('assets/js/jquery.menu-aim.js'); ?>" type="text/javascript"></script>

      </body>

      <!-- Mirrored from www.webstrot.com/html/tm/meatshop/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Jul 2020 18:54:21 GMT -->
      </html>