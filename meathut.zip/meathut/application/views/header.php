<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!DOCTYPE html>
<!-- 
   Template Name: Meat Hut India Pvt. Ltd.
   Version: 1.0
-->
<html lang="en">
<!-- Mirrored from www.webstrot.com/html/tm/meatshop/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Jul 2020 18:54:21 GMT -->
<head>
   <meta charset="utf-8">
   <meta content="IE=edge" http-equiv="X-UA-Compatible">
   <meta content="width=device-width, initial-scale=1" name="viewport">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

   <title><?php if(isset($title) && (!empty($title))){ echo $title; }else{ echo 'Meathut'; }?></title>

   <!-- All Stylesheets --> 
   <link href="<?php echo base_url('assets/css/all-stylesheets.css'); ?>" rel="stylesheet">
   <link href="<?php echo base_url('assets/css/custom-bootstrap-margin-padding.css'); ?>" rel="stylesheet">
   <link href="<?php echo base_url('assets/css/reset.css'); ?>" rel="stylesheet">

   <!--<link rel="stylesheet" type="text/css" href="css/animate.css" media="screen"> -->
   <!--HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
   <!--WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->

   <script src="<?php echo base_url('assets/js/jquery-1.12.4/jquery.min.js'); ?>"></script>
   <script src='../../../google_analytics_auto.js'></script>
</head>
<body>