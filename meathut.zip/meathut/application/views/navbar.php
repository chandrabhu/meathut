<body>
<!-- PRELOADER STARTS
      ========================================================================= -->
      <div id="preloader">
            <div id="status">
                  <div class="spinner"></div>
            </div>
      </div>
<!-- /. PRELOADER ENDS
      ========================================================================= -->
<!-- Start Top Bar
      ========================================================================= -->
      <div class="top-bar">
            <div class="container">
                  <div class="row">
                        <div class="col-md-9 col-sm-9 col-xs-6 contact-detail-column">
                              <!-- Start Contact Info -->
                              <ul class="contact-details">
                                    <li class="hidden-xs">
                                          <a href="http://meathut.in">Meathut India Est. 2020</a>
                                    </li>
                                    <li>
                                          <a href="tel:08709289369">
                                                <i class="fa fa-phone"></i>
                                                <b>08709289369</b> (Open Right Now)
                                          </a>
                                    </li>
                                    <li class="hidden-xs">
                                          <a href="mail:info@meathut.in">
                                                <i class="fa fa-paper-plane-o"></i>&nbsp;&nbsp;info@meathut.in
                                          </a>
                                    </li>
                              </ul>
                              <!-- End Contact Info -->
                        </div>
                        <!-- .col-md-6 -->
                        <div class="col-md-3 col-sm-3 col-xs-6">
                              <!-- Start Social Links -->
                              <ul class="social-list">
                                    <li>
                                          <a class="linkdin itl-tooltip" data-placement="bottom" title="" href="#">
                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                Hello Visitor !
                                          </a>
                                    </li>
                              </ul>
                              <!-- End Social Links -->
                        </div>
                        <!-- .col-md-6 -->
                  </div>
                  <!-- .row -->
            </div>
            <!-- .container -->
      </div>
      <!-- .top-bar -->

<!-- End Top Bar
      ========================================================================= -->
<!-- NAVIGATION STARTS
      ========================================================================= -->
      <div class="mobail_menu visible-xs">
            <div class="container-fluid">
                  <div class="row">	

                        <div class="col-sm-6 col-xs-6">
                              <div class="center_logo">
                                    <h4>
                                          <a href="<?php echo base_url(); ?>">
                                                <img src="<?php echo base_url('assets/images/logo/logo.jpg'); ?>" class="img-responsive" alt="logo"/>
                                          </a>
                                    </h4>
                              </div>
                        </div>

                        <div class="col-sm-6 col-xs-6">
                              <div class="cd-dropdown-wrapper">
                                    <a class="house_toggle" href="#0">
                                          <i class="fa fa-bars"></i>
                                    </a>
                                    <nav class="cd-dropdown">
                                          <h2>Meat Hut</h2>

                                          <a href="#0" class="cd-close">Close</a>

                                          <ul class="cd-dropdown-content">
                                                <li>
                                                      <a href="<?php echo base_url(); ?>">Home</a>
                                                </li>
                                                <li>
                                                      <a href="<?php echo base_url('meathut/about'); ?>">About</a>
                                                </li>
                                                <li>
                                                      <a href="<?php echo base_url('meathut/store'); ?>">Store</a>
                                                </li>
                                                <li>
                                                      <a href="<?php echo base_url('meathut/news'); ?>">News</a>
                                                </li>
                                                <li>
                                                      <a href="<?php echo base_url('meathut/contact'); ?>">Contact</a>
                                                </li>
                                          </ul> <!-- .cd-dropdown-content -->
                                    </nav> <!-- .cd-dropdown -->
                              </div>
                        </div>	
                  </div>		
            </div><!-- .cd-dropdown-wrapper -->	
      </div>		 

      <nav class="navbar navbar-default navigation normal hidden-xs">
            <div class="container">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand visible-xs" href="<?php echo base_url(); ?>">
                        <img src="<?php echo base_url('assets/images/logo/logo.jpg'); ?>" alt="logo">
                  </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav meet_logo">
                        <li class="">
                              <a class="navbar-brand hidden-xs" href="<?php echo base_url(); ?>">
                                    <img src="<?php echo base_url('assets/images/logo/logo.jpg'); ?>" alt="logo">
                              </a>
                        </li>
                  </ul>

                  <ul class="nav navbar-nav meet_navbar">
                        <li><a href="<?php echo base_url(); ?>">HOME</a></li>
                        <li><a href="<?php echo base_url('meathut/about'); ?>">ABOUT</a></li>
                        <li><a href="<?php echo base_url('meathut/store'); ?>">STORE</a></li>
                        <li><a href="<?php echo base_url('meathut/news'); ?>">NEWS</a></li>
                        <li><a href="<?php echo base_url('meathut/contact'); ?>">CONTACT</a></li>    
                  </ul>
                  
                  <ul class="dropdown-menu dpmenu pull-right">
                        <li class="pull-left">
                              <a href="#" class="clearfix">
                                    <!-- <img src="images/avatar-1.jpg" class="img-circle notification-avatar" alt="Avatar"> -->
                                    <span class="notification-title"></span>
                                    <span class="notification-ago"></span>
                                    <p class="notification-message"></p>
                              </a>
                        </li>
                        <li>
                              <a href="#" class="clearfix">
                                    <!-- <img src="images/avatar-2.jpg" class="img-circle notification-avatar" alt="Avatar"> -->
                                    <span class="notification-title"></span>
                                    <span class="notification-ago"></span>
                                    <p class="notification-message"></p>
                              </a>
                        </li>
                        <li>
                              <a href="#" class="clearfix">
                                    <!-- <img src="images/avatar-3.jpg" class="img-circle notification-avatar" alt="Avatar"> -->
                                    <span class="notification-title"></span>
                                    <span class="notification-ago"></span>
                                    <p class="notification-message"></p>
                              </a>
                        </li>
                        <li>
                              <a href="#" class="clearfix">
                                    <!-- <img src="images/avatar-4.jpg" class="img-circle notification-avatar" alt="Avatar"> -->
                                    <span class="notification-title"></span>
                                    <span class="notification-ago">&nbsp; &nbsp; &nbsp; &nbsp; No products in cart&nbsp; &nbsp; &nbsp; &nbsp; </span>
                                    <hr>
                                    <p class="notification-message"></p>
                              </a>
                        </li>
                  </ul>
            </div>
            <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
</nav>
<!-- /. NAVIGATION ENDS
      ========================================================================= -->
