

<div class="slider">
	<div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export"
	data-source="gallery"
	style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
	<!-- START REVOLUTION SLIDER 5.3.0.2 auto mode -->
	<div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.3.0.2">
		<ul>
			<!-- SLIDE  -->
			<li data-index="rs-3045" data-transition="zoomout" data-slotamount="default" data-hideafterloop="0"
			data-hideslideonmobile="off" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut"
			data-masterspeed="2000" data-thumb="" data-rotate="0" data-fstransition="fade"
			data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Intro"
			data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6=""
			data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
			<!-- MAIN IMAGE -->
			<img src="<?php echo base_url('assets/images/index/slide1.jpg'); ?>" alt="" data-bgposition="center center" data-bgfit="cover"
			data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
			<!-- LAYERS -->
			<!-- LAYER NR. 1 -->
			<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
			id="slide-3045-layer-1"
			data-x="['center','center','center','center']" data-hoffset="['230','230','300','700']"
			data-y="['middle','middle','middle','middle']" data-voffset="['-100','-130','100','70']"
			data-fontsize="['24','24','24','18']"
			data-lineheight="['24','24','24','22']"
			data-width="none"
			data-height="none"
			data-type="text"
			data-responsive_offset="on"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
			data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
			data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
			data-mask_out="x:inherit;y:inherit;"
			data-start="1000"
			style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
			src="<?php echo base_url('assets/images/index/1.png'); ?>" alt=""></div>
			<!--LAYER-2 -->
			<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
			id="slide-3045-layer-2"
			data-x="['center','center','center','center']" data-hoffset="['-380','-300','-200','-15']"
			data-y="['middle','middle','middle','middle']" data-voffset="['-100','-150','-150','-140']"
			data-fontsize="['34','34','34','40']"
			data-lineheight="['40','40','40','50']"
			data-width="none"
			data-height="none"
			data-type="text"
			data-responsive_offset="on"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
			data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
			data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
			data-mask_out="x:inherit;y:inherit;"
			data-start="2000"
			style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;">ORGANIC MEAT
			<br>AND SUSTAINABLE<br>SEA FOOD FOR YOU
		</div>
		<!-- LAYER NR. 3 -->
		<div class="tp-caption rev-btn  tp-resizeme"
		id="slide-3045-layer-3"
		data-x="['right','right','center','center']" data-hoffset="['995','800','-250','-90']"
		data-y="['middle','middle','middle','middle']" data-voffset="['10','-20','-10','20']"
		data-lineheight="['40','40','40','28']"
		data-width="none"
		data-height="none"
		data-whitespace="nowrap"
		data-type="button"
		data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":""}]'
		data-responsive_offset="on"
		data-frames='[{"from":"x:-50px;opacity:0;","speed":2500,"to":"o:1;","delay":3000,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"150","ease":"Power2.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 0);bw:2px 2px 2px 2px;"}]'
		data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
		data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
		data-transform_in="y:50px;opacity:0;s:1500;e:Power4.easeInOut;"
		data-transform_out="y:[175%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
		data-mask_out="x:inherit;y:inherit;"
		data-start="3000"
		data-textAlign="['center','center','center','center']"
		data-paddingtop="[5,5,5,20]"
		data-paddingright="[50,50,50,70]"
		data-paddingbottom="[5,5,5,20]"
		data-paddingleft="[50,50,50,70]"
		style="z-index: 11; white-space: nowrap; font-size: 14px; line-height: 40px; font-weight: 500; color:white;font-family:'Montserrat', sans-serif;background-color:#ef5350;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;letter-spacing:0px;cursor:pointer;border-radius:37px;">
		SHOP NOW
	</div>
	<!-- LAYER NR. 4 -->
	<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
	id="slide-3045-layer-4"
	data-x="['center','center','center','center']" data-hoffset="['-3','0','-20','850']"
	data-y="['middle','middle','middle','middle']" data-voffset="['180','50','100','70']"
	data-fontsize="['26','24','24','18']"
	data-lineheight="['30','24','24','22']"
	data-width="none"
	data-height="none"
	data-type="text"
	data-responsive_offset="on"
	data-whitespace="nowrap"
	data-transform_idle="o:1;"
	data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
	data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
	data-mask_out="x:inherit;y:inherit;"
	data-start="4000"
	style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
	src="<?php echo base_url('assets/images/index/2.png'); ?>" alt="">
</div>
<!-- LAYER NR.5 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-5"
data-x="['center','center','center','center']" data-hoffset="['-510','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','100','150','150']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-6"
data-x="['center','center','center','center']" data-hoffset="['-330','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','90','140','145']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Free delivery on orders over £50
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-7"
data-x="['center','center','center','center']" data-hoffset="['-370','-290','-197','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','110','160','170']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','30','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-8"
data-x="['center','center','center','center']" data-hoffset="['-100','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','200','250','250']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s1.jpg'); ?>" alt="">
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-9"
data-x="['center','center','center','center']" data-hoffset="['80','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','190','240','240']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Cut to order by Master Butchers
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3045-layer-10"
data-x="['center','center','center','center']" data-hoffset="['45','-290','-195','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','210','260','270']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3045-layer-11"
data-x="['center','center','center','center']" data-hoffset="['300','-430','300','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','300','500','50']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3045-layer-12"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','290','500','340']"
data-fontsize="['16','16','24','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Choose your own Date
</div>

<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3045-layer-13"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','310','500','365']"
data-fontsize="['12','12','24','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>

</li>
<!-- SLIDE  -->
<li data-index="rs-3046" data-transition="zoomout" data-slotamount="default" data-hideafterloop="0"
data-hideslideonmobile="off" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut"
data-masterspeed="2000" data-thumb="" data-rotate="0" data-fstransition="fade"
data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Intro"
data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6=""
data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="<?php echo base_url('assets/images/index/slide1.jpg'); ?>" alt="" data-bgposition="center center" data-bgfit="cover"
data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
<!-- LAYER NR. 1 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-1"
data-x="['center','center','center','center']" data-hoffset="['230','230','300','700']"
data-y="['middle','middle','middle','middle']" data-voffset="['-100','-130','100','70']"
data-fontsize="['24','24','24','18']"
data-lineheight="['24','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="1000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/1.png'); ?>" alt=""></div>
<!--LAYER-2 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-2"
data-x="['center','center','center','center']" data-hoffset="['-390','-300','-200','-15']"
data-y="['middle','middle','middle','middle']" data-voffset="['-100','-150','-150','-140']"
data-fontsize="['34','34','34','40']"
data-lineheight="['40','40','40','50']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="2000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;">ORGANIC MEAT
<br>AND SUSTAINABLE<br>SEA FOOD FOR YOU
</div>
<!-- LAYER NR. 3 -->
<div class="tp-caption rev-btn  tp-resizeme"
id="slide-3046-layer-3"
data-x="['right','right','center','center']" data-hoffset="['1000','800','-250','-90']"
data-y="['middle','middle','middle','middle']" data-voffset="['10','-20','-10','20']"
data-lineheight="['40','40','40','28']"
data-width="none"
data-height="none"
data-whitespace="nowrap"
data-type="button"
data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":""}]'
data-responsive_offset="on"
data-frames='[{"from":"x:-50px;opacity:0;","speed":2500,"to":"o:1;","delay":3000,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"150","ease":"Power2.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 0);bw:2px 2px 2px 2px;"}]'
data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
data-transform_in="y:50px;opacity:0;s:1500;e:Power4.easeInOut;"
data-transform_out="y:[175%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="3000"
data-textAlign="['center','center','center','center']"
data-paddingtop="[5,5,5,20]"
data-paddingright="[50,50,50,70]"
data-paddingbottom="[5,5,5,20]"
data-paddingleft="[50,50,50,70]"
style="z-index: 11; white-space: nowrap; font-size: 14px; line-height: 40px; font-weight: 500; color:white;font-family:'Montserrat', sans-serif;background-color:#ef5350;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;letter-spacing:0px;cursor:pointer;border-radius:37px;">
SHOP NOW
</div>
<!-- LAYER NR. 4 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-4"
data-x="['center','center','center','center']" data-hoffset="['-3','0','-20','850']"
data-y="['middle','middle','middle','middle']" data-voffset="['180','50','100','70']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/2.png'); ?>" alt="">
</div>
<!-- LAYER NR.5 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-5"
data-x="['center','center','center','center']" data-hoffset="['-510','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','100','150','150']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-6"
data-x="['center','center','center','center']" data-hoffset="['-330','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','90','140','145']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Free delivery on orders over £50
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-7"
data-x="['center','center','center','center']" data-hoffset="['-370','-290','-197','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','110','160','170']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','30','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-8"
data-x="['center','center','center','center']" data-hoffset="['-100','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','200','250','250']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s1.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-9"
data-x="['center','center','center','center']" data-hoffset="['80','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','190','240','240']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Cut to order by Master Butchers
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3046-layer-10"
data-x="['center','center','center','center']" data-hoffset="['45','-290','-195','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','210','260','270']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3046-layer-11"
data-x="['center','center','center','center']" data-hoffset="['300','-430','300','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','300','500','350']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3046-layer-12"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','290','500','340']"
data-fontsize="['16','16','24','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Choose your own Date
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3046-layer-13"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','310','500','365']"
data-fontsize="['12','12','24','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
</li>
<!--SLIDE-->
<li data-index="rs-3047" data-transition="zoomout" data-slotamount="default" data-hideafterloop="0"
data-hideslideonmobile="off" data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut"
data-masterspeed="2000" data-thumb="" data-rotate="0" data-fstransition="fade"
data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off" data-title="Intro"
data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6=""
data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
<!-- MAIN IMAGE -->
<img src="<?php echo base_url('images/index/slide1.jpg'); ?>" alt="" data-bgposition="center center" data-bgfit="cover"
data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
<!-- LAYERS -->
<!-- LAYER NR. 1 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-1"
data-x="['center','center','center','center']" data-hoffset="['230','230','300','700']"
data-y="['middle','middle','middle','middle']" data-voffset="['-100','-130','100','70']"
data-fontsize="['24','24','24','18']"
data-lineheight="['24','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="1000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/1.png'); ?>" alt=""></div>
<!--LAYER-2 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-2"
data-x="['center','center','center','center']" data-hoffset="['-380','-300','-200','20']"
data-y="['middle','middle','middle','middle']" data-voffset="['-100','-150','-150','-140']"
data-fontsize="['34','34','34','40']"
data-lineheight="['40','40','40','50']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="2000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;">ORGANIC MEAT
<br>AND SUSTAINABLE<br>SEA FOOD FOR YOU
</div>
<!-- LAYER NR. 3 -->
<div class="tp-caption rev-btn  tp-resizeme"
id="slide-3047-layer-3"
data-x="['right','right','center','center']" data-hoffset="['995','800','-250','-60']"
data-y="['middle','middle','middle','middle']" data-voffset="['10','-20','-10','20']"
data-lineheight="['40','40','40','28']"
data-width="none"
data-height="none"
data-whitespace="nowrap"
data-type="button"
data-actions='[{"event":"click","action":"scrollbelow","offset":"px","delay":""}]'
data-responsive_offset="on"
data-frames='[{"from":"x:-50px;opacity:0;","speed":2500,"to":"o:1;","delay":3000,"ease":"Power4.easeOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"},{"frame":"hover","speed":"150","ease":"Power2.easeInOut","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 0);bw:2px 2px 2px 2px;"}]'
data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
data-style_hover="c:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);cursor:pointer;"
data-transform_in="y:50px;opacity:0;s:1500;e:Power4.easeInOut;"
data-transform_out="y:[175%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="3000"
data-textAlign="['center','center','center','center']"
data-paddingtop="[5,5,5,20]"
data-paddingright="[50,50,50,70]"
data-paddingbottom="[5,5,5,20]"
data-paddingleft="[50,50,50,70]"
style="z-index: 11; white-space: nowrap; font-size: 14px; line-height: 40px; font-weight: 500; color:white;font-family:'Montserrat', sans-serif;background-color:#ef5350;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;letter-spacing:0px;cursor:pointer;border-radius:37px;">
SHOP NOW
</div>
<!-- LAYER NR. 4 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-4"
data-x="['center','center','center','center']" data-hoffset="['-3','0','-20','850']"
data-y="['middle','middle','middle','middle']" data-voffset="['180','50','100','70']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/2.png'); ?>" alt="">
</div>
<!-- LAYER NR.5 -->
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-5"
data-x="['center','center','center','center']" data-hoffset="['-510','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','100','150','150']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-6"
data-x="['center','center','center','center']" data-hoffset="['-330','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','90','140','145']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Free delivery on orders over £50
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-7"
data-x="['center','center','center','center']" data-hoffset="['-370','-290','-197','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','110','160','170']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','30','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-8"
data-x="['center','center','center','center']" data-hoffset="['-100','-430','-330','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','200','250','250']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s1.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-9"
data-x="['center','center','center','center']" data-hoffset="['80','-250','-165','55']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','190','240','240']"
data-fontsize="['16','16','16','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Cut to order by Master Butchers
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme"
id="slide-3047-layer-10"
data-x="['center','center','center','center']" data-hoffset="['45','-290','-195','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','210','260','270']"
data-fontsize="['12','12','12','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3047-layer-11"
data-x="['center','center','center','center']" data-hoffset="['300','-430','300','-150']"
data-y="['middle','middle','middle','middle']" data-voffset="['250','300','500','350']"
data-fontsize="['26','24','24','18']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;"><img
src="<?php echo base_url('assets/images/index/s2.jpg'); ?>" alt="">
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3047-layer-12"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['240','290','500','340']"
data-fontsize="['16','16','24','20']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize;">
Choose your own Date
</div>
<div class="tp-caption NotGeneric-SubTitle  tp-resizeme meet_slide_img1"
id="slide-3047-layer-13"
data-x="['center','center','center','center']" data-hoffset="['440','-290','300','10']"
data-y="['middle','middle','middle','middle']" data-voffset="['260','310','500','365']"
data-fontsize="['12','12','24','16']"
data-lineheight="['30','24','24','22']"
data-width="none"
data-height="none"
data-type="text"
data-responsive_offset="on"
data-whitespace="nowrap"
data-transform_idle="o:1;"
data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power3.easeInOut;"
data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
data-mask_out="x:inherit;y:inherit;"
data-start="4000"
style="z-index: 6; white-space: nowrap;text-transform:left; letter-spacing:0px;text-transform:capitalize; font-weight:400;">
Proin varius malesuada lacinia
</div>
</li>
</ul>
<div class="tp-bannertimer r tp-bottom" style="height: 7px; background-color:#ef5350;"></div>
</div>
</div>
</div>
<!-- Revolution Slider Ends -->
<div class="container about-firm-info">
	<div class="row butcher_img">
		<div class="col-lg-6 col-md-6 col-sm-6">
			<img class="img-responsive image_butcher" src="<?php echo base_url('assets/images/index/butcher_1.png'); ?>" alt="">
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 animated finite fadeInUp firm-padding">
			<div class="div_firms">
				<h1> About Our Firm’s </h1>
			</div>
			<div class="div_p">
				<p class="p-02">we are committed to total transparency about our products.</p>
			</div>
			<div class="div_line-yal2">
				<img class="img-responsive " src="images/index/under-line.png" alt="">
			</div>
			<div class="div_p">
				<p class="p1">Nunc elementum purus vel ex iaculis eleifend. Curabitur bibendum odio dui, at placerat
					antperer vitae. In hac habitasse platea dictumst. Phasellus nec sodales enim. Mauris malesuada nulla
					hole enim, nec eleifend lacus vulputate ut. Sed eu diam tellus. Sed feugiat, risus ut porta iaculis
					mauris metus volutpat metus, vitae egestas nibh neque vulputate libero.
				</p>
			</div>
			<div class="div_readmore1">
				<a href="#" class="btn_readMore55">Read more</a>
			</div>
		</div>
	</div>
</div>
<div class="img_background-hd ">
	<div class="container">
		<div class="row">
			<div class="div_margin-01">
				<div class="col-sm-12 div_home">
					<h1>Home Delivery</h1>
					<div class="butcher-delivery">
						<p>know about our delivery processes</p>
					</div>
					<div class="div_line-yal2">
						<img class="img-responsive " src="<?php echo base_url('assets/images/index/under-line.png'); ?>" alt="">
					</div>
					<div class="col-sm-12 div_icon_margin">
						<div class="col-lg-3 col-md-3 col-sm-3  home-delivery">
							<img class="img-responsive " src="<?php echo base_url('assets/images/index/icon01.png'); ?>" alt="">
							<h3 class="h3_class">CHOOSE</h3>
							<p class="p1"> Nunc elementum purus ex iaculis elfend. Curabitur bibendum odio</p>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3  home-delivery">
							<img class="img-responsive " src="<?php echo base_url('assets/images/index/icon02.png'); ?>" alt="">
							<h3 class="h3_class">RECEIVE</h3>
							<p class="p1"> Aunc elementum purus ex iaculis elfend. Curabitur bibendum odio</p>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3  home-delivery">
							<img class="img-responsive " src="<?php echo base_url('assets/images/index/icon03.png'); ?>" alt="">
							<h3 class="h3_class">COOK</h3>
							<p class="p1"> Nunc elementum purus ex iaculis elfend. Curabitur bibendum odio</p>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3  home-delivery">
							<img class="img-responsive " src="<?php echo base_url('assets/images/index/icon04.png'); ?>" alt="">
							<h3 class="h3_class">EAT</h3>
							<p class="p1"> Ucnc elementum purus ex iaculis elfend. Curabitur bibendum odio</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="portfolio-index" class="portfolio-index">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="prot-heading">
					<h1>Our Product’s</h1>
					<p>know about our delivery processes</p>
					<img src="<?php echo base_url('assets/images/index/under-line.png'); ?>" class="img-responsive" alt="">
				</div>
			</div>
		</div>
		<div class="row">
			<!-- Portfolio Nav Starts -->
			<div class="col-lg-12">
				<div id="options">
					<ul id="filters" class="option-set clearfix" data-option-key="filter">
						<li>
							<a href="#filter" data-option-value=".beef" class="aimgbeef">
								<img data-option-value=".beef" src="<?php echo base_url('images/index/tab-hv01.png'); ?>" alt="">
								<br>BEEF
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".lamb" class="aimglamb">
								<img data-option-value=".lamb" src="<?php echo base_url('images/index/tab-hv2.png'); ?>" alt="">
								<br>LAMB
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".pork">
								<img data-option-value=".pork" src="<?php echo base_url('images/index/tab-hv3.png'); ?>" alt="">
								<br>PORK
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".poultry">
								<img data-option-value=".poultry" src="<?php echo base_url('images/index/tab-hv4.png'); ?>" alt="">
								<br>POULTRY
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".sausage">
								<img data-option-value=".sausage" src="<?php echo base_url('images/index/tab-hv5.png'); ?>" alt="">
								<br>SAUSAGE
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".deli">
								<img data-option-value=".deli" src="<?php echo base_url('images/index/tab-hv6.png'); ?>" alt="">
								<br>DELI
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".fish">
								<img data-option-value=".fish" src="<?php echo base_url('images/index/tab-hv8.png'); ?>" alt="">
								<br>FISH
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".bbq">
								<img data-option-value=".bbq" src="<?php echo base_url('images/index/tab-hv7.png'); ?>" alt="">
								<br>BBQ PACK
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".crab">
								<img data-option-value=".crab" src="<?php echo base_url('images/index/tab-hv9.png'); ?>" alt="">
								<br>CRAB
							</a>
						</li>
						<li>
							<a href="#filter" data-option-value=".shrimp">
								<img data-option-value=".shrimp" src="<?php echo base_url('images/index/tab-hv10.png'); ?>" alt="">
								<br>SHRIMP
							</a>
						</li>
						<li class="display-all">
							<a href="#filter" data-option-value="*" class="selected">
								<img src="<?php echo base_url('images/products/11.png'); ?>" alt="">
								<br>VIEW ALL
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>


	<div class="container">
		<div class="row">
			<!-- Portfolio Nav Ends -->
			<div class="col-lg-12">
				<!-- Portfolio Thumbs Starts -->
				<div class="make3columns portfolio-grid isotope">
					<!-- Project 1 Starts -->
					<figure class="item videos beef isotope-item fish bbq shrimp">
						<div class="picture article">
							<img src="<?php echo base_url('assets/images/products/1.jpg'); ?>" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3>
											<a href="#">Lamb Shanks</a>
										</h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star5" name="rating" value="5"><label class="full"
											for="star5"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star4half" name="rating" value="4 and a half"><label
											class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star4" name="rating" value="4"><label class="full"
											for="star4"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star3half" name="rating" value="3 and a half"><label
											class="half" for="star3half" title="Meh - 3.5 stars"></label>
											<input type="radio" id="star3" name="rating" value="3"><label class="full"
											for="star3"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star2half" name="rating" value="2 and a half"><label
											class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star2" name="rating" value="2"><label class="full"
											for="star2"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star1half" name="rating" value="1 and a half"><label
											class="half" for="star1half" title="Meh - 1.5 stars"></label>
											<input type="radio" id="star1" name="rating" value="1"><label class="full"
											for="star1"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf" name="rating" value="half"><label
											class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 1 Ends -->
					<!-- Project 2 Starts -->
					<figure class="item mobileapps lamb isotope-item bbq crab">
						<div class="picture article">
							<img src="images/products/2.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star51" name="rating" value="5"><label class="full"
											for="star51"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star41half" name="rating"
											value="4 and a half"><label class="half" for="star41half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star41" name="rating" value="4"><label class="full"
											for="star41"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star31half" name="rating"
											value="3 and a half"><label class="half" for="star31half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star31" name="rating" value="3"><label class="full"
											for="star31"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star21half" name="rating"
											value="2 and a half"><label class="half" for="star21half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star21" name="rating" value="2"><label class="full"
											for="star21"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star11half" name="rating"
											value="1 and a half"><label class="half" for="star11half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star11" name="rating" value="1"><label class="full"
											for="star11"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf1" name="rating" value="half"><label
											class="half" for="starhalf1" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 2 Ends -->
					<!-- Project 3 Starts -->
					<figure class="item crab lamb isotope-item">
						<div class="picture article">
							<img src="images/products/3.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star52" name="rating" value="5"><label class="full"
											for="star52"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star42half" name="rating"
											value="4 and a half"><label class="half" for="star42half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star42" name="rating" value="4"><label class="full"
											for="star42"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star32half" name="rating"
											value="3 and a half"><label class="half" for="star32half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star32" name="rating" value="3"><label class="full"
											for="star32"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star22half" name="rating"
											value="2 and a half"><label class="half" for="star22half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star22" name="rating" value="2"><label class="full"
											for="star22"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star12half" name="rating"
											value="1 and a half"><label class="half" for="star12half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star12" name="rating" value="1"><label class="full"
											for="star1"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf2" name="rating" value="half"><label
											class="half" for="starhalf2" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 3 Ends -->
					<!-- Project 4 Starts -->
					<figure class="item mobileapps pork isotope-item beef crab">
						<div class="picture article">
							<img src="images/products/4.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star53" name="rating" value="5"><label class="full"
											for="star53"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star43half" name="rating"
											value="4 and a half"><label class="half" for="star43half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star43" name="rating" value="4"><label class="full"
											for="star43"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star33half" name="rating"
											value="3 and a half"><label class="half" for="star33half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star33" name="rating" value="3"><label class="full"
											for="star33"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star23half" name="rating"
											value="2 and a half"><label class="half" for="star23half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star23" name="rating" value="2"><label class="full"
											for="star23"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star13half" name="rating"
											value="1 and a half"><label class="half" for="star13half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star13" name="rating" value="1"><label class="full"
											for="star13"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf3" name="rating" value="half"><label
											class="half" for="starhalf3" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 4 Ends -->
					<!-- Project 5 Starts -->
					<figure class="item lamb pork shrimp isotope-item beef poultry">
						<div class="picture article">
							<img src="images/products/5.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star54" name="rating" value="5"><label class="full"
											for="star54"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star44half" name="rating"
											value="4 and a half"><label class="half" for="star44half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star44" name="rating" value="4"><label class="full"
											for="star44"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star34half" name="rating"
											value="3 and a half"><label class="half" for="star34half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star34" name="rating" value="3"><label class="full"
											for="star34"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star24half" name="rating"
											value="2 and a half"><label class="half" for="star24half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star24" name="rating" value="2"><label class="full"
											for="star24"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star14half" name="rating"
											value="1 and a half"><label class="half" for="star14half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star14" name="rating" value="1"><label class="full"
											for="star14"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf4" name="rating" value="half"><label
											class="half" for="starhalf4" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 5 Ends -->
					<!-- Project 6 Starts -->
					<figure class="item fish shrimp isotope-item pork">
						<div class="picture article">
							<img src="images/products/6.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star55" name="rating" value="5"><label class="full"
											for="star55"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star45half" name="rating"
											value="4 and a half"><label class="half" for="star45half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star45" name="rating" value="4"><label class="full"
											for="star45"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star35half" name="rating"
											value="3 and a half"><label class="half" for="star35half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star35" name="rating" value="3"><label class="full"
											for="star35"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star25half" name="rating"
											value="2 and a half"><label class="half" for="star25half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star25" name="rating" value="2"><label class="full"
											for="star25"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star15half" name="rating"
											value="1 and a half"><label class="half" for="star15half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star15" name="rating" value="1"><label class="full"
											for="star15"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf5" name="rating" value="half"><label
											class="half" for="starhalf5" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 6 Ends -->
					<!-- Project 7 Starts -->
					<figure class="item bbq sausage isotope-item poultry deli">
						<div class="picture article">
							<img src="images/products/1.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star56" name="rating" value="5"><label class="full"
											for="star56"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star46half" name="rating"
											value="4 and a half"><label class="half" for="star46half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star46" name="rating" value="4"><label class="full"
											for="star46"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star36half" name="rating"
											value="3 and a half"><label class="half" for="star36half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star36" name="rating" value="3"><label class="full"
											for="star36"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star26half" name="rating"
											value="2 and a half"><label class="half" for="star26half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star26" name="rating" value="2"><label class="full"
											for="star26"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star16half" name="rating"
											value="1 and a half"><label class="half" for="star16half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star16" name="rating" value="1"><label class="full"
											for="star16"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf6" name="rating" value="half"><label
											class="half" for="starhalf6" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 7 Ends -->
					<!-- Project 8 Starts -->
					<figure class="item poultry deli isotope-item sausage">
						<div class="picture article">
							<img src="images/products/1.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star57" name="rating" value="5"><label class="full"
											for="star57"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star47half" name="rating"
											value="4 and a half"><label class="half" for="star47half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star47" name="rating" value="4"><label class="full"
											for="star47"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star37half" name="rating"
											value="3 and a half"><label class="half" for="star37half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star37" name="rating" value="3"><label class="full"
											for="star37"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star27half" name="rating"
											value="2 and a half"><label class="half" for="star27half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star27" name="rating" value="2"><label class="full"
											for="star27"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star17half" name="rating"
											value="1 and a half"><label class="half" for="star17half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star17" name="rating" value="1"><label class="full"
											for="star17"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf7" name="rating" value="half"><label
											class="half" for="starhalf7" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 8 Ends -->
					<!-- Project 9 Starts -->
					<figure class="item deli fish isotope-item sausage">
						<div class="picture article">
							<img src="images/products/2.jpg" class="img-responsive" alt="">
							<div class="entry">
								<div class="row">
									<div class="col-lg-12">
										<h3><a href="#">Lamb Shanks</a></h3>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<a href="#" class="date">2 X 454G/ 160Z</a>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<fieldset class="rating">
											<input type="radio" id="star58" name="rating" value="5"><label class="full"
											for="star58"
											title="Awesome - 5 stars"></label>
											<input type="radio" id="star48half" name="rating"
											value="4 and a half"><label class="half" for="star48half"
											title="Pretty good - 4.5 stars"></label>
											<input type="radio" id="star48" name="rating" value="4"><label class="full"
											for="star48"
											title="Pretty good - 4 stars"></label>
											<input type="radio" id="star38half" name="rating"
											value="3 and a half"><label class="half" for="star38half"
											title="Meh - 3.5 stars"></label>
											<input type="radio" id="star38" name="rating" value="3"><label class="full"
											for="star38"
											title="Meh - 3 stars"></label>
											<input type="radio" id="star28half" name="rating"
											value="2 and a half"><label class="half" for="star28half"
											title="Kinda bad - 2.5 stars"></label>
											<input type="radio" id="star28" name="rating" value="2"><label class="full"
											for="star28"
											title="Kinda bad - 2 stars"></label>
											<input type="radio" id="star18half" name="rating"
											value="1 and a half"><label class="half" for="star18half"
											title="Meh - 1.5 stars"></label>
											<input type="radio" id="star18" name="rating" value="1"><label class="full"
											for="star18"
											title="Sucks big time - 1 star"></label>
											<input type="radio" id="starhalf8" name="rating" value="half"><label
											class="half" for="starhalf8" title="Sucks big time - 0.5 stars"></label>
										</fieldset>
										<h5>$10.00</h5>
									</div>
								</div>
								<a class="btn btn-read" href="#">ADD TO CART</a>
							</div>
						</div>
					</figure>
					<!-- Project 9 Ends -->
				</div>
				<!-- Portfolio Thumbs Ends -->
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-sm-12 product_div">
			<div class="col-lg-6 col-md-6 col-sm-6 firm-padding">
				<div class="div_firms">
				</div>
				<div>
					<h1 class="b-team"> Our Butchery Team </h1>
				</div>
				<div class="div_p">
					<p class="p-02">we are committed to total transparency about our products.</p>
				</div>
				<div class="div_line-yal-index">
					<img class="img-responsive " src="images/index/line-yal.png" alt="">
				</div>
				<div class="div_p">
					<p class="p1">Nunc elementum purus vel ex iaculis eleifend. Curabitur bibendum odio dui, at placerat
						antperer vitae. In hac habitasse platea dictumst. Phasellus nec sodales enim. Mauris malesuada
						nulla hole enim, nec eleifend lacus vulputate ut. Sed eu diam tellus. Sed feugiat, risus ut
						porta iaculis mauris metus volutpat metus, vitae egestas nibh neque vulputate.
					</p>
				</div>
				<div class="div_readmore-red1">
					<a href="#" class="btn_readMore-red12">Read more</a>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-6 ">
				<img class="img-responsive" src="images/index/butcher_2.png" alt="">
			</div>
		</div>
		<div class="col-sm-12 product_box_margin">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="products_box_2">
						<img class="img-responsive" src="images/index/team1.jpg" alt="">
						<h2>Shams Tabrez</h2>
						<p> OWNER</p>
						<div class="social_icon">
							<i class="fa fa-facebook facebook_icon" aria-hidden="true"></i>
							<i class="fa fa-twitter twitter_icon" aria-hidden="true"></i>
							<i class="fa fa-google-plus google_icon" aria-hidden="true"></i>
							<i class="fa fa-linkedin linkedin_icon" aria-hidden="true"></i>
						</div>
					</div>
				</div>
				<div class="col-lg-4  col-md-4 col-sm-4 col-xs-12">
					<div class="products_box_2">
						<img class="img-responsive" src="images/index/team2.jpg" alt="">
						<h2>Jhon Doe</h2>
						<p> SNR. BUTCHER</p>
						<div class="social_icon">
							<i class="fa fa-facebook facebook_icon" aria-hidden="true"></i>
							<i class="fa fa-twitter twitter_icon" aria-hidden="true"></i>
							<i class="fa fa-google-plus google_icon" aria-hidden="true"></i>
							<i class="fa fa-linkedin linkedin_icon" aria-hidden="true"></i>
						</div>
					</div>
				</div>
				<div class="col-lg-4  col-md-4 col-sm-4 col-xs-12">
					<div class="products_box_2">
						<img class="img-responsive" src="images/index/team3.jpg" alt="">
						<h2>Lisa Doe</h2>
						<p> SALES PERSONS</p>
						<div class="social_icon">
							<i class="fa fa-facebook facebook_icon" aria-hidden="true"></i>
							<i class="fa fa-twitter twitter_icon" aria-hidden="true"></i>
							<i class="fa fa-google-plus google_icon" aria-hidden="true"></i>
							<i class="fa fa-linkedin linkedin_icon" aria-hidden="true"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="img_backdround-contact">
	<div class="container">
		<div class="border-div">
			<div class="row">
				<div class="col-lg-offset-6 col-lg-5 col-md-offset-6 col-md-6">
					<div class="contact">
						<h2>CALL NOW</h2>
					</div>
					<div class="div_line-yal-index">
						<img class="img-responsive " src="images/blog/line-yal-red.png" alt="">
					</div>
				</div>
			</div>
			<div class="row dashed-border">
				<div class="col-lg-offset-6 col-lg-5 col-md-offset-6 col-md-6">
					<div class="phone">
						<h2>+1 800 123 4567</h2>
					</div>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla condimentum<br class="visible-sm">laoreet
						velit ut rhoncus. Class aptent taciti sociosqu ad litora torquent <br class="visible-sm">per
						conubia nostra
					</p>
					<div class="div_readmore-red">
						<a href="#" class="btn_readMore-red123">Read more</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="home-news-blog">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 news-blog">
				<h1>New’s & Blog’s</h1>
				<p>know about our delivery processes</p>
				<img src="images/index/under-line.png" class="img-responsive" alt="">
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="pictures-overlay-2">
					<div class="btch-2">
						<div class="btch-2-img">
							<img src="images/index/blog1.jpg" alt="" class="img-responsive">
						</div>
						<div class="box">
							<p> July / 15 / 2016</p>
							<h1>Aorem ipsum dolor sit amet consect.</h1>
							<div class="read-more-btn">
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="pictures-overlay-2">
					<div class="btch-2">
						<div class="btch-2-img">
							<img src="images/index/blog2.jpg" alt="" class="img-responsive">
						</div>
						<div class="box">
							<p> July / 15 / 2016</p>
							<h1>Aorem ipsum dolor sit amet consect.</h1>
							<div class="read-more-btn">
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4">
				<div class="pictures-overlay-2">
					<div class="btch-2">
						<div class="btch-2-img">
							<img src="images/index/blog3.jpg" alt="" class="img-responsive">
						</div>
						<div class="box">
							<p> July / 15 / 2016</p>
							<h1>Aorem ipsum dolor sit amet consect.</h1>
							<div class="read-more-btn">
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class=" img_background-hd">
	<div id="parallax-one" class="parallax ">
		<div class="parallax-text-container-1">
			<div class="parallax-text-item">
				<div class="container">
					<div class="row funfacts">
						<div class="col-lg-3 col-md-3 col-sm-3">
							<div class="block">
								<i class="fa fa-circle-thin counter_i counter-item-circle"></i>
								<div class="count blue-text">500</div>
								<div class="caption1">CUSTOMER’S</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3">
							<div class="block">
								<i class="fa fa-circle-thin counter_i-green counter-item-circle"></i>
								<div class="count green-text">394</div>
								<div class="caption2">MEATS TYPE’S</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3">
							<div class="block">
								<i class="fa fa-circle-thin counter_i-red counter-item-circle"></i>
								<div class="count red-text">745</div>
								<div class="caption3">ORGANIC FARM’S</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3">
							<div class="block">
								<i class="fa fa-circle-thin counter_i-yellow counter-item-circle"></i>
								<div class="count yellow-text">423</div>
								<div class="caption4">HOUTLET’S</div>
							</div>
						</div>
					</div>
					<div class="funfacts-para">
						<div class="row">
							<div class="col-lg-2 col-md-2 col-sm-2"></div>
							<div class="col-lg-8 col-md-8 col-sm-8">
								<img class="img-responsive" src="images/index/line-cd.png" alt="">
								<p>Donec blandit, tellus sed molestie posuere, erat lorem tempor enim, vestibulum
									tincidunt ex diam in elit. Suspendisse sed ipsum nibh. Proin euismod luctus mauris,
									quis scelerisque arcu ultricies condimentum. Donec pellentesque dictum tellus, ut
									tincidunt nibh ultricies vitae. Etiam luctus justo eu tellus maximus, id venenatis
									sem euismod.
								</p>
							</div>
							<div class="col-lg-2 col-md-2 col-sm-2"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-12" data-wow-delay="0.2s">
			<div class="carousel slide" data-ride="carousel" id="quote-carousel">
				<!-- Bottom Carousel Indicators -->
				<ol class="carousel-indicators hidden-xs">
					<li data-target="#quote-carousel" data-slide-to="0" class="active"><img class="img-responsive "
						src="images/index/tes1.jpg"
						alt="">
					</li>
					<li data-target="#quote-carousel" data-slide-to="1"><img class="img-responsive"
						src="images/index/provider_5.jpg" alt="">
					</li>
					<li data-target="#quote-carousel" data-slide-to="2"><img class="img-responsive"
						src="images/index/provider_8.jpg" alt="">
					</li>
				</ol>
				<!-- Carousel Slides / Quotes -->
				<div class="carousel-inner">
					<!-- Quote 1 -->
					<div class="item active">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4">
								<img src="images/index/tes1.jpg" alt="" class="img-responsive">
							</div>
							<div class="col-sm-8 carousel-row">
								<div class="name"> Ibn Battuta</div>
								<div class="status"> BUSINESSMAN</div>
								<p class="carousel-quote"><span class="quote"></span>
									Donec blandit, tellus sed
									molestie posuere, erat lorem tempor enim, vestibulum
									tincidunt ex diam in elit. Suspendisse sed ipsum nibh. Proin euismod luctus mauris,
									quis scelerisque arcu ultricies condimentum.
								</p>
							</div>
						</div>
					</div>
					<!-- Quote 2 -->
					<div class="item">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4">
								<img src="images/index/provider_5.jpg" alt="" class="img-responsive">
							</div>
							<div class="col-sm-8 carousel-row">
								<div class="name"> Ibn Battuta</div>
								<div class="status"> BUSINESSMAN</div>
								<p class="carousel-quote"><span class="quote"></span>
									Donec blandit, tellus sed
									molestie posuere, erat lorem tempor enim, vestibulum
									tincidunt ex diam in elit. Suspendisse sed ipsum nibh. Proin euismod luctus mauris,
									quis scelerisque arcu ultricies condimentum.</>
								</div>
							</div>
						</div>
						<!-- Quote 3 -->
						<div class="item">
							<div class="row">
								<div class="col-lg-4 col-md-4 col-sm-4">
									<img src="images/index/provider_8.jpg" alt="" class="img-responsive">
								</div>
								<div class="col-sm-8 carousel-row">
									<div class="name"> Ibn Battuta</div>
									<div class="status"> BUSINESSMAN</div>
									<p class="carousel-quote"><span class="quote"></span>
										Donec blandit, tellus sed
										molestie posuere, erat lorem tempor enim, vestibulum
										tincidunt ex diam in elit. Suspendisse sed ipsum nibh. Proin euismod luctus mauris,
										quis scelerisque arcu ultricies condimentum.
									</p>
								</div>
							</div>
						</div>
					</div>
					<!-- Carousel Buttons Next/Prev -->
					<a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i
						class="fa fa-chevron-left"></i></a>
						<a data-slide="next" href="#quote-carousel" class="right carousel-control"><i
							class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
			</div>
			<div class="contact_img_background">
				<div class="container">
					<div class="row">
						<div class="col-lg-2 col-md-2 col-sm-2 send-your-request">
							<img src="images/logo/12.png" alt="">
						</div>
						<div class="col-lg-6 col-md-7 col-sm-8 col-sm-offset-2 col-md-offset-3 col-lg-offset-4 send-your-request">
							<div class="kc_title">
								<h1>Send Your Request</h1>
								<p> we are committed to total transparency about our products.</p>
							</div>
							<div class="div_line-yal">
								<img class="img-responsive " src="images/index/line-yal.png" alt="">
							</div>
						</div>
					</div>
					<div class="row contact-bg-border">
						<div class="col-lg-4 col-md-4 col-sm-4 cont-block">
							<div class="row block-foter">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 vcenter">
									<img src="images/index/icon-contact.png" class="img-responsive" alt="">
								</div>
								<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 vcenter pl-0">
									<div class="detail-foter">
										<h1>PO Box 16122 Collins Street West Victoria 8007</h1>
									</div>
								</div>
							</div>
							<div class="row block-foter">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 vcenter">
									<img src="images/index/icon-contact.png" class="img-responsive" alt="">
								</div>
								<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 vcenter pl-0">
									<div class="detail-foter">
										<h1>121 King Street, Melbourne
											Victoria 3000
										</h1>
									</div>
								</div>
							</div>
							<div class="row block-foter">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 vcenter">
									<img src="images/index/icon-contact.png" class="img-responsive" alt="">
								</div>
								<div class="col-lg-8 col-md-8 col-xs-8 vcenter pl-0">
									<div class="detail-foter">
										<h1>+1 800 123 4567</h1>
									</div>
								</div>
							</div>
							<div class="row block-foter">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 vcenter">
									<img src="images/index/icon-contact.png" class="img-responsive" alt="">
								</div>
								<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 vcenter pl-0">
									<div class="detail-foter">
										<h1>info@example.com</h1>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-lg-offset-2 col-md-offset-2  div_margin">
							<div class="form-footer">
								<form>
									<div class="form-group">
										<label class="sr-only" for="inlineFormInputGroup">Username</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="fa fa-user"></i></div>
											<input type="text" name="full_name" class="form-control require" id="inlineFormInputGroup">
										</div>
									</div>
									<div class="form-group">
										<label class="sr-only" for="inlineFormInputGroup">Message</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="fa fa-envelope"></i></div>
											<input type="text" name="email" class="form-control require" data-valid="email" data-error="Email should be valid." id="inlineFormInputGroup">
										</div>
									</div>
									<div class="form-group">
										<label class="sr-only" for="inlineFormInputGroup">Phone</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="fa fa-phone"></i></div>
											<input type="text" name="contact_no" class="form-control require" id="inlineFormInputGroup">
										</div>
									</div>
									<div class="form-group  form-textarea">
										<label class="sr-only" for="inlineFormInputGroup">Phone</label>
										<div class="input-group">
											<div class="input-group-addon"><i class="fa fa-pencil-square-o"></i></div>
											<textarea rows="3" name="message"  class="form-control"></textarea>
										</div>
									</div>
									<div class="div_readmore">	
										<div class="response"></div>
										<div class="btn_send12">							
											<button type="button" class="submitForm" form-type="inquiry">send now</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="container div_margin">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 pl-0 pr-0">
						<div class="col-lg-3 col-md-3 col-sm-3  brand">
							<img src="images/index/brand1.jpg" class="brand-img" alt="">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 brand">
							<img src="images/index/brand2.jpg" class="brand-img" alt="">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 brand">
							<img src="images/index/brand3.jpg" class="brand-img" alt="">
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 brand">
							<img src="images/index/brand4.jpg" class="brand-img" alt="">
						</div>
					</div>
				</div>
			</div>