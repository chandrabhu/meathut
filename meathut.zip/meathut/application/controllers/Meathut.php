<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meathut extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index()
	{
		$data["title"] = 'Welcome to Meathut';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('welcome_message');
		$this->load->view('footer');
	}

	public function about()
	{
		$data["title"] = 'About-Us';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('about');
		$this->load->view('footer');
	}

	public function store()
	{
		$data["title"] = 'Store';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('store');
		$this->load->view('footer');
	}

	public function contact()
	{
		$data["title"] = 'Contact-Us';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('contact');
		$this->load->view('footer');
	}


	public function privacy_policy()
	{
		$data["title"] = 'Privacy-policy';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('privacy_policy');
		$this->load->view('footer');
	}

	public function terms_and_conditions()
	{
		$data["title"] = 'Terms and Conditions';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('terms_n_conditions');
		$this->load->view('footer');
	}
	public function faq()
	{
		$data["title"] = 'FAQs';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('faq');
		$this->load->view('footer');
	}

	public function works()
	{
		$data["title"] = 'Works';

		$this->load->view('header');
		$this->load->view('navbar');
		$this->load->view('works');
		$this->load->view('footer');
	}
}
